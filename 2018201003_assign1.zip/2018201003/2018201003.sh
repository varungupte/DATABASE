python 2018201003.py "$1"
