#include<bits/stdc++.h>
using namespace std;
queue<int> inputBuffer;
queue<string> outputBuffer;
unsigned int input__size,output__size;

typedef struct BtreeNode
{
	BtreeNode* parent;
	bool isDead;
	bool isLeaf;
	vector<int> keys;
	vector<BtreeNode*> pointer;
	BtreeNode* buffer;
	
}BtreeNode;

const int null = 1000000001;
const int ninf = -1000000000;

BtreeNode* initializing_node(int n, bool ss)
{
	BtreeNode* node = new BtreeNode;
	node->isDead = false;
	node->buffer = NULL;
	node->parent = NULL;
	node->keys = vector<int>(n, null);
	node->pointer = vector<BtreeNode*>(n+1);
	node->isLeaf =ss;
	
	return node;
}
void isAlive(BtreeNode* parent, BtreeNode* child, int value)
{
	if(parent != NULL)
	{
		bool flag = false;
		int s=0;
		for (int i = 1; i < parent->pointer.size(); ++i)
		{
			if(child == parent->pointer[i])
			{
				s=1;
				parent->keys[i - 1] = value;
			}
		}
		if(parent->isDead && s==1)
		{
			isAlive(parent->parent, parent, value);
		}
	}
}


BtreeNode* insert(BtreeNode* node, int value)
{
	int node_size = node->keys.size();
	BtreeNode* root = NULL;
	int s=0;
	if(node->keys[node_size - 1] != null)
	{
		s=1;
	}
	if(s==1)
	{
		int pp, newVal,tempIndex;

		vector<int> tempKeys = node->keys;

		vector<BtreeNode*> tempPointers = node->pointer;

		tempIndex = upper_bound(tempKeys.begin(), tempKeys.end(), value) - tempKeys.begin();
		
		tempKeys.insert(tempKeys.begin() + tempIndex, value);

		if(node->isLeaf==false)
		{
			tempPointers.insert(tempPointers.begin() + tempIndex + 1, node->buffer);
		}
		BtreeNode* new_node = initializing_node(node_size, node->isLeaf);
		new_node->parent = node->parent;
		if(node->isLeaf)
		{
			new_node->pointer[node_size] = node->pointer[node_size];
			node->pointer[node_size] = new_node;
			double tempFloat = node_size + 1;
			pp = (int)ceil(tempFloat/2);
		}
		else
		{
			double tempFloat = node_size + 2;
			pp = (int)ceil((tempFloat)/2);

			for (int i = 0; i < tempPointers.size(); ++i)
			{
				if(i < pp)
				{
					node->pointer[i] = tempPointers[i];
				}
				else
				{
					new_node->pointer[i - pp] = tempPointers[i];
					new_node->pointer[i - pp]->parent = new_node;
					if(i <= node_size)
					{
						node->pointer[i] = NULL;
					}
				}
			}

			pp=pp-1;
			newVal = tempKeys[pp];
			tempKeys.erase(tempKeys.begin() + pp);
		}
		for (int i = 0; i < tempKeys.size(); ++i)
		{
			if(i < pp)
			{
				node->keys[i] = tempKeys[i];
			}
			else
			{
				new_node->keys[i - pp] = tempKeys[i];
				if(i < node_size)
				{
					node->keys[i] = null;
				}
			}
		}

		if(node->isDead && value != node->keys[0] && tempIndex < pp)
		{
			node->isDead = false;
			isAlive(node->parent, node, value);
		}

		tempIndex = upper_bound(new_node->keys.begin(), new_node->keys.end(), node->keys[pp - 1]) - new_node->keys.begin();
		if(new_node->keys[tempIndex] == null)
		{
			newVal = new_node->keys[0];
			new_node->isDead = true;
		}
		else if(node->isLeaf)
		{
			newVal = new_node->keys[tempIndex];
		}


		if(node->parent != NULL)
		{
		
			node->parent->buffer = new_node;
			root = insert(node->parent, newVal);
		}
		else
		{
			root = initializing_node(node_size, false);
			root->keys[0] = newVal;
			root->pointer[0] = node;
			root->pointer[1] = new_node;
			node->parent = root;
			new_node->parent = root;
		}
	}
	else
	{
		
		bool insert_flag = false;
		int ss=0;
		int tempKey = null;
		BtreeNode* tempPointer = NULL;
		for (int i = 0; i < node_size; i++)
		{
			if(ss==1)
			{
				swap(node->keys[i], tempKey);
				if(node->isLeaf==false)
				{
					swap(node->pointer[i + 1], tempPointer);
				}
			}
			else
			{
				if(value < node->keys[i] || node->keys[i] == null)
				{
					ss = 1;
					tempKey = node->keys[i];
					node->keys[i] = value;
					if(node->isLeaf==false)
					{
						tempPointer = node->pointer[i + 1];
						node->pointer[i + 1] = node->buffer;
					}
				}
				if(value != node->keys[0] && node->isDead==true)
				{
					node->isDead = false;
					isAlive(node->parent, node, value);
				}
			}
		}
	}
	return root;
}


BtreeNode* lookup(BtreeNode* node, int value, bool up)
{
	while(!node->isLeaf)
	{
		int lower_limit = ninf, upper_limit, node_size = node->keys.size(), index;
		for (int i = 0; i < node_size; i++)
		{
			upper_limit = node->keys[i];
			if((node->keys[i] == null))
			{
				index = i;
				break;
			}
			
			if((lower_limit <= value && value < upper_limit)||(lower_limit <= value && value == upper_limit && !up && node->pointer[i + 1]->isDead))
			{
				index = i;
				break;
			}
			else
			{
				index = i + 1;
			}
			lower_limit = upper_limit;
		}
		node = node->pointer[index];
	}
	return node;
}

BtreeNode* insert_val(BtreeNode* root, int value)
{
	BtreeNode* temp2=lookup(root, value, true);
	BtreeNode* temp = insert(temp2, value);
	if(temp != NULL)
	{
		root = temp;
	}
	return root;
}
BtreeNode* lookup_tree(BtreeNode* node, int value, bool up)
{
	while(!node->isLeaf)
	{
		int lower_limit = ninf, upper_limit, node_size = node->keys.size(), index;
		for (int i = 0; i < node_size; i++)
		{
			if(node->keys[i] == null)
			{
				index = i;
				break;
			}
		}
		node = node->pointer[index];
	}
	return node;
}

bool find__value(BtreeNode* leaf, int val)
{
	int s=0;
	for (int i = 0; i < leaf->keys.size(); ++i)
	{
		if(leaf->keys[i] == val)
		{
			s=1;
			break;
		}
	}
	if(s==0)
	{
		return false;
	}
	else
	{
		return true;
	}
}
BtreeNode* insert_valued(BtreeNode* root, int value)
{
	BtreeNode* temp2=lookup(root, value, true);
	BtreeNode* temp;
	temp = insert(temp2, value);
	if(temp != NULL)
	{
		root = temp;
	}
	return root;
}
int count__value(BtreeNode* leaf, int val)
{
	int count = 0, flag = false, last_index = leaf->pointer.size() - 1;
	int s=0;
	while(leaf != NULL)
	{
		for (int i = 0; i < leaf->keys.size(); ++i)
		{
			if(leaf->keys[i] == val)
			{
				count=count+1;
			}
			else if(leaf->keys[i] > val && leaf->keys[i] != null)
			{
				s=1;
				break;
			}
		}
		if(s==1)
		{
			break;
		}
		leaf = leaf->pointer[last_index];
	}
	return count;
}

int Range_query(BtreeNode* leaf, int lower_limit, int upper_limit)
{
	int count = 0, last_index = leaf->pointer.size() - 1;
	int s=0;
	while(leaf != NULL)
	{
		for (int i = 0; i < leaf->keys.size(); ++i)
		{
			if(leaf->keys[i] >= lower_limit && leaf->keys[i] <= upper_limit)
			{
				count=count+1;
			}
			else if(leaf->keys[i] > upper_limit && leaf->keys[i] != null)
			{
				s=1;
				break;
			}
		}
		if(s==1)
		{
			break;
		}
		leaf = leaf->pointer[last_index];
	}
	return count;
}

void treedisplay(BtreeNode* node)
{
	if(node == NULL)
	{
		return;
	}
	if(!node->isLeaf)
	{
		for (int i = 0; i < node->pointer.size(); ++i)
		{
			treedisplay(node->pointer[i]);
		}
	}
	else
	{
		cout << "L:";
	}
	cout << "|";
	for (int i = 0; i < node->keys.size(); ++i)
	{
		if(node->keys[i] == null)
		{
			cout << "n|";
		}
		else
		{
			cout << node->keys[i] << "|";
		}
	}
	cout << endl;
}


void output_buffer_clean() 
{
    string output;
    while(!outputBuffer.empty())
    {
        output = outputBuffer.front();
        outputBuffer.pop();
        cout << output << '\n';
    }
}
void input_buffer_clean(BtreeNode* root)
{
    int index,val1=0,val2=0;
    stringstream ans;
    while(!inputBuffer.empty())
    {
        if(outputBuffer.size() == output__size) 
        {
            output_buffer_clean();
        }
        index = inputBuffer.front();
        inputBuffer.pop();
        if(index == 1)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            root = insert_val(root,val1);
        }
        else if(index == 3)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            if(find__value(lookup(root, val1, false), val1))
            {
				outputBuffer.push("YES");
            }
			else
			{
				outputBuffer.push("NO");
			}
        }
        else if(index == 2)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            val2 = inputBuffer.front();
            inputBuffer.pop();
            ans << Range_query(lookup(root, val1, false), val1, val2);
            outputBuffer.push(ans.str());
        }

        else if(index == 4)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            ans << count__value(lookup(root, val1, false), val1);
            outputBuffer.push(ans.str());
        }
        ans.str("");
    }
}
void buffer_clean(BtreeNode* root)
{
    int index,val1,val2;
    stringstream ans;
    while(!inputBuffer.empty())
    {
        if(outputBuffer.size() == output__size) 
        {
            output_buffer_clean();
        }
        index = inputBuffer.front();
        inputBuffer.pop();
        if(index == 1)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            root = insert_val(root,val1);
        }
        else if(index == 3)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            if(find__value(lookup(root, val1, false), val1))
            {
				outputBuffer.push("YES");
            }
			else
			{
				outputBuffer.push("NO");
			}
        }
        else if(index == 2)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            val2 = inputBuffer.front();
            inputBuffer.pop();
            ans << Range_query(lookup(root, val1, false), val1, val2);
            outputBuffer.push(ans.str());
        }

        else if(index == 4)
        {
            val1 = inputBuffer.front();
            inputBuffer.pop();
            ans << count__value(lookup(root, val1, false), val1);
            outputBuffer.push(ans.str());
        }
        ans.str("");
    }
}

void inputbufferread(char const* fileName,BtreeNode* root)
{
    int val1,val2;
    string line;
    ifstream infile(fileName);
	while(getline(infile, line))
	{
        if(inputBuffer.size()+2 >= input__size)
        {
            input_buffer_clean(root);
        }
        if(line.find("INSERT") != string::npos)
		{
		    istringstream (line.substr(7)) >> val1;
            inputBuffer.push(1);
            inputBuffer.push(val1);
        }
        else if(line.find("RANGE") != string::npos)
        {
            istringstream (line.substr(6)) >> val1 >> val2;
            inputBuffer.push(2);
            inputBuffer.push(val1);
            inputBuffer.push(val2);
        }
        else if(line.find("COUNT") != string::npos)
        {
            istringstream (line.substr(6)) >> val1;
            inputBuffer.push(4);
            inputBuffer.push(val1);
        }
        else if(line.find("FIND") != string::npos)
        {
            istringstream (line.substr(5)) >> val1;
            inputBuffer.push(3);
            inputBuffer.push(val1);
        }
        else
            cout << "Invalid Command : " << line;
    }
}

void display(BtreeNode* node)
{
	if(node == NULL)
	{
		return;
	}
	if(!node->isLeaf)
	{
		for (int i = 0; i < node->pointer.size(); ++i)
		{
			display(node->pointer[i]);
		}
	}
	else
		cout << "L:";
	cout << "|";
	for (int i = 0; i < node->keys.size(); ++i)
	{
		if(node->keys[i] == null)
		{
			cout << "n|";
		}
		else
		{
			cout << node->keys[i] << "|";
		}
	}
	cout << endl;
}
void buffer_read(char const* fileName,BtreeNode* root)
{
    int val1,val2;
    string line;
    ifstream infile(fileName);
	while(getline(infile, line))
	{
        if(inputBuffer.size()+2 >= input__size)
        {
            input_buffer_clean(root);
        }
        if(line.find("INSERT") != string::npos)
		{
		    istringstream (line.substr(7)) >> val1;
            inputBuffer.push(1);
            inputBuffer.push(val1);
        }
        else if(line.find("RANGE") != string::npos)
        {
            istringstream (line.substr(6)) >> val1 >> val2;
            inputBuffer.push(2);
            inputBuffer.push(val1);
            inputBuffer.push(val2);
        }
        else if(line.find("COUNT") != string::npos)
        {
            istringstream (line.substr(6)) >> val1;
            inputBuffer.push(4);
            inputBuffer.push(val1);
        }
        else if(line.find("FIND") != string::npos)
        {
            istringstream (line.substr(5)) >> val1;
            inputBuffer.push(3);
            inputBuffer.push(val1);
        }
        else
            cout << "Invalid Command : " << line;
    }
}

int main(int argc, char const *argv[])
{
	if(argc < 4) 
	{
		cout << "Please provide the command as follows:- : ./a.out <filename> <numBuffers <bufferSize>  ";
		cout<<endl;
        exit(-1);
	}
	char file_name[200];
	strcpy(file_name,argv[1]);

	int M=(long long) (argv[2]); 
	int B=(long long) argv[3];   

	if(M < 2 || B < 4) 
	{
        cout << "Value of M(number of buffers) should be >=2 and B(buffer size) >=4 ";
        cout<<endl;
        exit(-1);
    }

	input__size = (M-1)*B/4;
	output__size = B/4;
	
	int n = (B - 8)/12;
	if(n < 2)
	{
		n = 2;
	}
    BtreeNode* root = initializing_node(n, true);
    buffer_read(file_name,root);
    input_buffer_clean(root);
    output_buffer_clean();
	return 0;
}
