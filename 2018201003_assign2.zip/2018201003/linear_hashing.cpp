#include<bits/stdc++.h>
using namespace std;

queue<long long int> input__Buffer, output__Buffer;
long long int inputSize, outputSize,num__Buffers, buffer__Size;

class Block
{
	Block *block_overflow;
    vector<long long int> records;
    public:
    Block() 
    {
        block_overflow = NULL;
        records.clear();
    }
    void add(long long int x) 
    {
        long long int y = buffer__Size/4;
        if(records.size() < (y)) // as sizeof(int) is 4
        {
            records.push_back(x);
        }
        else 
        {
            if(block_overflow == NULL)
            {
                block_overflow = new Block();
            }
            block_overflow->add(x);
        }
    }

    bool isPresent(int x) 
    {
        Block *node = this;
        while(node) 
        {
            for(long long int i = 0; i < node->records.size(); i++)
             {
                if(node->records[i] == x) 
                {
                    return true;
                }
            }
            node = node->block_overflow;
        }
        return false;
    }

     void insertElements(long long int x) 
    {
        long long int y = buffer__Size/4;

        if(records.size() < (y)) 
        {
            records.push_back(x);
        }
        else 
        {
            if(block_overflow == NULL)
            {
                block_overflow = new Block();
            }
            block_overflow->add(x);
        }
    }

    void removeElements(vector<long long int> &v) 
    {
        for(long long int i = 0; i < records.size(); i++) 
        {
            v.push_back(records[i]);
        }
        records.clear();
        if(block_overflow) 
        {
            block_overflow->removeElements(v);
            delete block_overflow;
            block_overflow = NULL;
        }
    }
};


class HashTable 
{
    vector<Block *> buckets;int numRecords, numBits;
    public:

	//constructor for hashtable
    HashTable() 
    {
    	buckets.push_back(new Block());
        buckets.push_back(new Block());
        numRecords = 0;numBits = 1;
    }

    long long int filled() 
    {
        double ratio = (1.0 * numRecords) / buckets.size();
        long long int p=(long long int)(100 * (ratio / (buffer__Size / 4)));
        return p;
    }

    long long int hashfunction(long long int x) 
    {
        long long int mod = (1 << numBits);
        long long int p=(long long int)(x % mod + mod) % mod;
        return p;
    }

    long long int hashfunction_another(long long int x) 
    {
        long long int mod = (1 << numBits);
        long long int p=(long long int)(x) % mod;
        return p;
    }

    bool checkpresent(long long int x) 
    {
        long long int k = hashfunction(x);
        if(k >= buckets.size()) 
        {
            k -= (1 << (numBits - 1));
        }
        if(buckets[k]->isPresent(x)) {
            return true;
        }
        return false;
    }

    void insert(long long int x) 
    {
        long long int k = hashfunction(x);
        if(k >= buckets.size()) 
        {
            k = k - (1 << (numBits - 1));
        }
        buckets[k]->add(x);
        numRecords=numRecords+1;
        while(filled()>=75) 
        {
            buckets.push_back(new Block());
            numBits = ceil(log2((double)buckets.size()));

            k = buckets.size() - 1 - (1 << (numBits - 1));
            vector<long long int> v;
            buckets[k]->removeElements(v);
            for(long long int i = 0; i < v.size(); i++)
            {
                buckets[hashfunction(v[i])]->add(v[i]);
            }
        }
    }

    bool isPresent(long long int x) 
    {
        long long int k = hashfunction(x);
        if(k >= buckets.size())
        {
            k = k - (1 << (numBits - 1));
        }
        if(buckets[k]->isPresent(x)) 
        {
            return true;
        }
        return false;
    }
   

};


HashTable h;
void output_queue_clear() 
{
    int out_front;
    while(!output__Buffer.empty()) 
    {
        out_front = output__Buffer.front();
        output__Buffer.pop();
        cout<<out_front;
        cout<<endl;
    }
}

void input_queue_clear() {
    int input_front;
    while(!input__Buffer.empty()) 
    {
        input_front = input__Buffer.front();
        input__Buffer.pop();
        if(!h.isPresent(input_front)) 
        {
            h.insert(input_front);
            if(output__Buffer.size() == outputSize) 
            {
                output_queue_clear();
            }
            output__Buffer.push(input_front);
        }
    }
}
int main(int argc, char *argv[]) 
{
    if(argc < 4) 
    {
        cout << "Please provide the command as follows:- : ./a.out <filename> <bufferSize> <numBuffers> "<<endl;
        exit(-1);
    }
    ifstream input(argv[1]);
    buffer__Size = atoi(argv[2]); 
    num__Buffers = atoi(argv[3]); 
    if(num__Buffers < 2 || buffer__Size < 4) 
    {
        cout << "Value of M(number of buffers) should be >=2 and B(buffer size) >=4 ";
        cout<<endl;
        exit(-1);
    }
    buffer__Size = atoi(argv[2]); 
    num__Buffers = atoi(argv[3]);
    long long int pp=(buffer__Size/4);
    inputSize = (num__Buffers-1)*pp;
    outputSize = pp;
    long long int x=0;
    cout<<"UNIQUE ELEMENTS ARE :-";
    cout<<endl;
    while(input >> x) 
    {
        if(input__Buffer.size() < inputSize)
        {
            input__Buffer.push(x);
        }
        else 
        {
            input_queue_clear();
            input__Buffer.push(x);
        }
    }
    
    input_queue_clear();
    output_queue_clear();
    return 0;
}