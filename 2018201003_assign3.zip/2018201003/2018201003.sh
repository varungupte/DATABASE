a=0
b=1
for var in "$@"
do 
	a=`expr $a + $b`
	# echo $@
done
if [ $a == 2 ]
then 
	python2 2018201003_1.py $1 $2
else
	python2 2018201003_2.py $1
fi