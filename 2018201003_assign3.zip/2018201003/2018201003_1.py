import copy
import sys
i = 0
fname = sys.argv[1]
q = int(sys.argv[2])
disc = {}
mainmemory = {}
active = []
mz=[]
transact = {}
mapping = {}
a = []
last=0
ss=0
varx={}
local = {}
mm = 0
notifier = 0
xx=0
filename='2018201003_1.txt'
fout = open(filename, "w")

with open(fname,'r') as f:
	ss=ss+1
	c = 0
	for line in f:
		if c == 0:
			xx=xx+1
			var = line.split(" ")
			i = 0
			while i < len(var):
				ss=ss+1
				pi=var[i+1]
				kk=int(pi)
				p2=var[i]
				disc[p2]=kk
				p3=var[i+1]
				kk2=int(p3)
				p4=var[i]
				mainmemory[p4]=kk2
				i=i+2
		else:
			if notifier == 1:
				var = line.split(" ")
				m2=mm
				p5=var[0]
				mapping[p5]=m2
				mapping[m2]=p5
				ss=ss+1
				varx[m2]=[]
				transact[m2]=[]
				last=last+1
				mm = mm + 1
				at = var[0]
				notifier = 0
			else:
				if line=="\n":
					last=last+1
					notifier = 1
				else:
					last=last+1
					notifier = 0
					p8=mapping[at]
					transact[p8].append(line)

		c = c + 1


maxlen = 0

for i in transact.keys():
	t1=transact[i]
	ttl=len(t1)
	if maxlen < ttl:
		maxlen = ttl

i = 0
while i < maxlen:
	for j in transact.keys():
		x = 0
		while x < q :
			t1=transact[j]
			ttl=len(t1)
			if x+i<ttl:
				a.append((j,transact[j][x+i]))
				xx=xx+1
				x=x+ 1 
			else:
				xx=xx-1
				break

	i = i + q
	ss=ss+1
last=last+1
trans = map(lambda x: (x[0], x[1].strip("\n")), a)
xx=xx+1
nl = 0
last=last-25
for i in trans:
	xx=xx-1
	if i[0] not in active:
		ss=ss+xx-2
		active.append(i[0])
		ii1=i[0]
		wr = '<START '+ mapping[ii1]+'>'
		fout.write(wr)
		fout.write("\n")
		kk = mainmemory.keys()
		kk.sort()
		sp = 0
		for w in kk:
			if w in mz:
				mwm=mainmemory[w]
				g=str(mwm)
				if sp == 0:
					wr=w
					wr =wr+" "+g
				else:
					wr=" "
					wr = wr+w+" "+g
				sp = sp+1 
				fout.write(wr)
		fout.write("\n")
		kk = disc.keys()
		kk.sort()
		sp = 0
		for w in kk:
			gg=str(disc[w])
			if sp == 0:
				wr=w
				wr = wr +" "+ gg
			else:
				wr=" "
				wr = wr+w +" "+ gg
			sp = sp + 1
			fout.write(wr)
		fout.write("\n")
	
	e = i[1]
	
	

	if 'WRITE' in e:
		last=last+1
		temp = e.split('(')[1].split(')')[0].split(',')
		temp = map(lambda x: x.strip(), temp)
		p1=i[0]
		p2=temp[0]
		p3=mainmemory[p2]
		p4=str(p3)
		wr = '<'+mapping[p1]+', '+temp[0]+', '+p4+'>'
		last=last+1
		fout.write(wr)
		fout.write("\n")
		ss1=temp[0]
		ss2=temp[1]
		ss3=local[ss2]
		mainmemory[ss1] = ss3
		kk = mainmemory.keys()
		kk.sort()
		sp = 0
		for w in kk:
			if w in mz:
				ggg=str(mainmemory[w])
				if sp == 0:
					wr=w
					wr=wr+" "+ggg
				else:
					wr = " "
					wr=wr+w+" "+ggg
				sp=sp+5
				sp = sp - 4
				fout.write(wr)
		ss=ss+1
		fout.write("\n")
		xx=xx+1
		kk = disc.keys()
		kk.sort()
		sp = 0
		for w in kk:
			if sp == 0:
				gggg=str(disc[w])
				wr=w
				wr = wr +" "+gggg
			else:
				gggg=str(disc[w])
				wr=" "
				wr = wr +w+" "+gggg
			sp=sp+25
			sp = sp - 24
			xx=xx+1
			fout.write(wr)
		fout.write("\n")

	if 'READ' in e:
		
		temp = e.split('(')[1].split(')')[0].split(',')
		temp = map(lambda x: x.strip(), temp)
		ss1=temp[1]
		ss2=temp[0]
		ss3=mainmemory[ss2]
		local[ss1] = ss3
		if temp[0] not in varx[i[0]]:
			kl=temp[0]
			mz.append(kl)
			ij=i[0]
			varx[ij].append(kl)

	if '=' in e:
		
		temp = e.split(':=')
		last=last+1
		temp = map(lambda x: x.strip(), temp)
		m1=copy.deepcopy(mainmemory)
		ss1=temp[0]
		ss2=temp[1]
		local[ss1] = eval(ss2, m1, local)

	if 'OUTPUT' in e:
		
		temp = e.split('(')[1].split(')')[0]
		disc[temp] = mainmemory[temp]
		kk2=i[0]
		l = varx[kk2]
		l.remove(temp)
		kk3=len(l)
		if kk3 == 0:
			kk4=i[0]
			wr = '<COMMIT '+ mapping[kk4]+'>'
			fout.write(wr)
			fout.write("\n")
			kk = mainmemory.keys()
			kk.sort()
			sp = 0
			for w in kk:
				if w in mz:
					if sp == 0:
						ggggg=str(mainmemory[w])
						wr=w+" "+ggggg
					else:
						ggggg=str(mainmemory[w])
						wr=" "+w+" "+ggggg
					fout.write(wr)
					sp = sp + 1

			fout.write("\n")
			ss=ss+1
			kk = disc.keys()
			kk.sort()
			sp = 0
			last=last+1
			for w in kk:
				ppw=0
				if sp == 0 and ppw == 0:
					hh=str(disc[w])
					wr=w+" "+hh
				else:
					hh=str(disc[w])
					wr = " "+w+" "+hh
				fout.write(wr)
				sp = sp + 1
			if nl != len(trans)-1:
				xx=xx+1
				fout.write("\n")
	nl = nl + 1
	ss=ss+1
fout.write("\n")
fout.close()