import sys
import copy
w=0
filepath = sys.argv[1] 
transact_dict={}
final_dict={}
tran=[]
tran2=[]
flag=0
res=[]
ss=0
start_ckpt_dict={}
start_new={}
start_end={}
prev_ckpt_dict={}
prev_new={}
prev_end={}
yy=0
xx=25
with open(filepath) as fp:  
   line = fp.readline()
   if len(line):
        xx=xx+25
        line=line[0:-1]
        list1=line.split(" ")
        for i in range(0,len(list1),2):
            p1=list1[i]
            p2=list1[i+1]
            final_dict[p1]=p2
   
   while line:
        line = fp.readline()
        p2=1
        if len(line)!=0 and len(line)!=1 and p2:
            line=line[1:-2]
            if line[0]=='T':
                yy=yy+5
                list1=line.split(", ")
                p3=list1
                res.append(p3)
            else:
                yy=yy+2
                list1=line.split(" ")
                p3=list1
                res.append(p3)
        else:
            ss=ss+1
            line = fp.readline()
l2=len(res)
total_log=l2
for inst in range(total_log-1,-1,-1):
    ss=ss+1
    if res[inst][0]=='COMMIT':
        g1=res[inst][1]
        tran.append(g1)
    if res[inst][0][0]=='T' and res[inst][0] not in tran:
        g2=res[inst][1]
        g3=res[inst][2]
        final_dict[g2]=g3
    if res[inst][0]=='START' and res[inst][1]=='CKPT':
        if flag==1:
            ss=ss+1
            break
    if res[inst][0]=='END' and res[inst][1]=='CKPT':
        xx=xx+1
        flag=1

ans=""

list_key=final_dict.keys()
list_key.sort()
for i in list_key:
    yy=yy+1
    ans+=i
    ans+=" "+final_dict[i]+" "
ans=ans[0:-1]
filename="2018201003_2.txt"
with open(filename,"w") as fp:
    fp.write(ans)
    fp.write("\n")
    fp.close()
    

